user_name = input()

''' Type your code here. '''
print("Hello",user_name,"and welcome to CS Online!")